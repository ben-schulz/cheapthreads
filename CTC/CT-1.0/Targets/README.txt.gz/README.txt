this is ~/cheapthreads/CTC/CT-1.0/Targets/

Instruction syntaxes, instruction selectors, and other target-specific
compiler passes for the CT compiler.

Put here 2010.11.18

Schulz
