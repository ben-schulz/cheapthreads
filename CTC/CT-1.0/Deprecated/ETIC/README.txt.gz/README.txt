this is ~/cheapthreads/CTC/CT-1.0/Deprecated/ETIC/

A modified branch of Adam and Andrew's work on ETIC, used to generate code
for the APLAS'10 submission.  This version differs from that Adam and Andrew
have been actually been working with, and has been geared mostly toward the
construction of a better intermediate form.  A new syntax has since been
constructed, however, and even if ETIC continues to occupy a place in the
compiler phases, it will not likely be the version stored here.

put here 2010.08.16

Schulz
