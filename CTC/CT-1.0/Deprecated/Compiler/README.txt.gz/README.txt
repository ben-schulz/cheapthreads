
This directory contains the working version of the CT-to-ETIC
code generator.

Initiated 2010.04.14.

2010.05.26 Schulz
