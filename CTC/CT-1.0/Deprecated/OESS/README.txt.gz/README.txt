This is '~/cheapthreads/CTC/CT-1.0/CT/OESS'

The operational execution-stream semantics (OESS), an operationalized version
of CT expressed as an imperative, thread-based language.  This is an
intermediate representation used by the CT compiler (CTC), redesigned from
the effect-typed interrupt calculus (ETIC).

This project is another front in the effort to develop a usable and even
somewhat institutionally respectable CT compiler, opened on 2010.06.17
and presently ongoing.

This code and its dependencies are all loaded from '../../Test.hs',
where all testing facilities should be located.

Remember: No cash returns -- only credit toward future purchases.

--Schulz
