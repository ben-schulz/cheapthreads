The files in this directory are deprecated.  Do not use them.

CT-to-ETIC code generation module is now located in:

  ~/cheapthreads/CTC/CT-1.0/CT/Compiler/


2010.05.26 Schulz
