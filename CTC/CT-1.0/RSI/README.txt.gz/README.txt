this is ~/cheapthreads/CTC/CT-1.0/RSI/

The third and final attempt at constructing an intermediate form to
immediately follow the source-phase passes of the CT compiler, including
syntax definitions and code generation.

RSI is a high-level imperative language with atomicity primitives; the
subdirectories 'RSI_*' contain different implementations of atomicity,
e.g. via jumps, via interrupts, or via hypoethetical hardware.

"Carnegie-Mellon will fall.  Haskell zealots will fall.  Earth will crumble."

Put here 2010.08.16

Schulz
