This is ~/cheapthreads/CTC/CT-1.0/Theory/

Interpreters, abstract machines, derivations and other verificaiton material
for CT and the CT compiler

put here 2010.08.02

Schulz
